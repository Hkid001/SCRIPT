# 🎬 Script Lab – By Holy Kid

**Script Lab** is a personal and creative portfolio website for showcasing my work as a screenwriter. Built using HTML and CSS, this site presents a clean, professional platform to display original scripts, share writing tips, and connect with collaborators, producers, or clients.

---

## 📄 What You'll Find

- 🎥 **Portfolio:** My best original screenplays and writing samples.
- 🧠 **Blog:** Insights into storytelling, script structure, and creative process.
- 👤 **About:** My journey as a scriptwriter and the stories I love to tell.
- 💼 **Services:** Scriptwriting services for short films, features, and more.
- 🎨 **Gallery:** Visual inspiration, concept art, and storyboards.
- 📬 **Contact:** Let’s connect and create something powerful.

---

## 💡 Technologies Used

- HTML5
- CSS3
- Hosted on GitHub Pages

---

## 📌 Purpose

This project is part of my journey as a writer to:
- Build an online presence.
- Share scripts with producers and fans.
- Inspire and collaborate with other creatives.

> *“I write not just to entertain, but to move hearts. Every story deserves to be told.”* – **Holy Kid**